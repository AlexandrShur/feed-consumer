from urllib.request import urlopen
import xml.etree.ElementTree as ET
from xml.etree.ElementTree import ElementTree
import io
from datetime import datetime
import os
import boto3
import json

def get_title(item):
    return item.find('title').text

def get_items_from_rss(url):
    try:
        response = urlopen(url)
        tree = ET.parse(response)
        root = tree.getroot()
        return root.iter('item')
    except:
        print("Invalid source link encountered: [%s]" % (url))
        return None

def add_unique_items(new_items_url, channel, existing_titles):
    items_to_process = get_items_from_rss(new_items_url)
    if items_to_process is not None:
        items_to_process = list(filter(lambda item: get_title(item) not in existing_titles, items_to_process))
        channel.extend(items_to_process)

def save_rss(tree, url):
    tree.getroot().find('channel').find('lastBuildDate').text = str(datetime.now())

    xmlstr = ET.tostring(tree.getroot(), encoding='utf8', method='xml')
    
    bucket = os.environ['bucket']
    s3 = boto3.resource("s3")
    s3.Bucket(bucket).put_object(Key=url, Body=xmlstr, ACL = "public-read", Metadata={'cache-control':'max-age'})
    
def process_sources(sources, rss_link, tree, channel, existing_titles):
    for source in sources:
        add_unique_items(source, channel, existing_titles)
        save_rss(tree, rss_link)

def get_sources_objects():
    bucket = os.environ['bucket']
    key_prefix = "sources/"
    s3 = boto3.resource("s3")
    bc3 = s3.Bucket(bucket);
    result = []
    for source in bc3.objects.filter(Prefix=key_prefix).all():
        result.append(source.get()['Body'].read().decode('utf-8'))    
    return result

def create_raw_rss(rss_title, rss_link):
    return ElementTree(ET.fromstring("""<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<rss xmlns:atom="http://www.w3.org/2005/Atom" xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:slash="http://purl.org/rss/1.0/modules/slash/" xmlns:sy="http://purl.org/rss/1.0/modules/syndication/" xmlns:wfw="http://wellformedweb.org/CommentAPI/" version="2.0">
    <channel>
        <title>{rss_title}</title>
        <atom:link href="{rss_link}" rel="self" type="application/rss+xml"/>
        <link>{rss_link}</link>
        <description/>
        <lastBuildDate></lastBuildDate>
        <language>en-US</language>
        <sy:updatePeriod>hourly</sy:updatePeriod>
        <sy:updateFrequency>1</sy:updateFrequency>
    </channel>
</rss>
""".format(rss_title=rss_title, rss_link=rss_link)))

def process_suorces_objects(sources_objects):
    for sources_object in sources_objects:
        tree = None
        sources_object = json.loads(sources_object)
        rss_link = sources_object['rssLink']
        
        bucket = os.environ['bucket']
        s3 = boto3.resource("s3")
        bc3 = s3.Bucket(bucket);
        exstingRsss = []
        for rss in bc3.objects.filter(Prefix=rss_link).all():
            exstingRsss.append(rss.get()['Body'].read().decode('utf-8'))
        if len(exstingRsss) > 0:
            tree = ElementTree(ET.fromstring(exstingRsss[0]))
        else:
            print("RSS [%s] doesn't exist, creating new one." % (rss_link))
            tree = create_raw_rss(sources_object['name'], rss_link)

        root = tree.getroot()

        channel = root.find('channel')
        existing_titles = [];
        for item in channel.findall('item'):
            existing_titles.append(get_title(item))
                
        process_sources(sources_object['sources'], rss_link, tree, channel, existing_titles)

def lambda_handler(event, context):
    process_suorces_objects(get_sources_objects())
    
    return {
        'statusCode': 200
    }
