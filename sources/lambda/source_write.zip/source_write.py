import json
import os
import base64
import boto3

def remove_invalid_sources(sources):
    return list(filter(lambda source: source is not None and len(source) > 0, sources))

def lambda_handler(event, context):
    
    bucket = os.environ['bucket']
    user = event['requestContext']['authorizer']['jwt']['claims']['username']
    
    payload = base64.b64decode(event['body'])
    payload = json.loads(payload)
    source_name = payload['name']
    sources = payload['sources']
    
    validation_errors = None
    if source_name is None or len(source_name) == 0:
        validation_errors = "Name should be defined."
    if user is None or len(user) == 0:
        validation_errors = "User doesn't exist."
    if sources is None:
        validation_errors = "Sources are not defined."
    sources = remove_invalid_sources(sources)
    if len(sources) == 0:
        validation_errors = "No source was specified."
    
    if validation_errors is not None:
        return {
            'statusCode': 200,
            'body': validation_errors
        }
    
    source_name = source_name.replace(" ", "_")
    payload['name'] = source_name
    payload['rssLink'] = "rss/" + user + "/" + source_name + "/feed";
    key_prefix = "sources/" + user;
    key = key_prefix + "/" + source_name
    
    s3 = boto3.resource("s3")
    s3.Bucket(bucket).put_object(Key=key, Body=json.dumps(payload))
    
    return {
        'statusCode': 200,
        'body': payload['rssLink']
    }
