import json
import os
import base64
import boto3

def lambda_handler(event, context):
    bucket = os.environ['bucket']
    user = event['requestContext']['authorizer']['jwt']['claims']['username']
    key_prefix = "sources/" + user;
    s3 = boto3.resource("s3")
    bc3 = s3.Bucket(bucket);
    result = []
    for source in bc3.objects.filter(Prefix=key_prefix).all():
        result.append(source.get()['Body'].read().decode('utf-8'))
    
    return {
        'statusCode': 200,
        'body': json.dumps(result)
    }
